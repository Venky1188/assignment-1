
$(function(){
var User=function(name){
        this.name=name;
        this.id=Math.floor( Math.random(  ) * 100 )+1;
        this.mediator=null;
        this.domId=this.name+"-"+this.id;
        this.track = {};
        
        this.sendMessage=function(mess ){
           this.mediator.sendMessagetoUsers(mess);
         };
           
         this.receiveMessage = function(message){
           $( "#messageTemplate" ).template( "listAttendees");
           $.tmpl( "listAttendees" ,{"message":message}).appendTo( "#"+this.domId+" section" );
           this.updateOperation(message);
         };
     this.updateOperation=function(message){
     if(!this.track[this.domId] ){
       this.track[this.domId]=[];
     }
     this.track[this.domId].push(message);
     };
     
  this.template = function(obj){
    $("#attendeesTemplate").template( "listAttendees" );
    $.tmpl("listAttendees", obj).appendTo(".chat-frame-container").each(function(  ){
      $( "#"+obj.domId).find( ".send" ).click(function(  ){
       var val=obj.domId+":"+$(this).siblings( "input" ).val();
       obj.sendMessage(val);
       $(this).siblings( "input" ).val("");
      });
    });
  };
  this.printSavedMessage = function( arr ){
  arr.forEach( ( val )=>{
    $( "#messageTemplate" ).template( "listAttendees" );
    $.tmpl( "listAttendees",{"message":val} ).appendTo( "#"+this.domId+"  section" );
  
  } );
  };
  
  }
  
  var ChatMediator=function(  ){
    this.users = [];
    this.register = function( user ){
     this.users.push(user);
     user.mediator = this;
    };
    this.sendMessagetoUsers =function(message){
      this.schema = [];
      this.users.forEach( (user) =>{
        user.receiveMessage.call(user,message);
        this.schema.push( user.track );
      } );
      
      sessionStorage.setItem( "model",JSON.stringify( this.schema ) );
    };
    
    this.createSavedObject = function( object ){
      var domId = Object.keys( object )[0];
      var name,id;
      [name , id] = domId.split( "-" );
      var obj = new User( name );
      obj.domId = domId;
      obj.id = id;
      obj.mediator = this;
      obj.track = object;
      obj.template( obj );
      obj.printSavedMessage( obj.track[domId] );
      this.users.push( obj );
    };
  }
  
  var chatMediator = new ChatMediator();
  $(".add").click( function() {
      var user=	$("input[ type='text']").val();
      if( user == "" || user== undefined){
        return false;
      }
      var obj = new User(user);
      chatMediator.register(obj);
      obj.template(obj);
      $( "input[ type='text']").val("");
  });
  
  
  //On page refresh

  if( sessionStorage.getItem( "model" )){
     var data = JSON.parse( sessionStorage.getItem( "model" ));
     data.forEach( ( obj ) =>{
       chatMediator.createSavedObject( obj );
     } );
  }
});